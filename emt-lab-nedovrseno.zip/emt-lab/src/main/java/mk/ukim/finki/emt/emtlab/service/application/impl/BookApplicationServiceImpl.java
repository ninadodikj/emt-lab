package mk.ukim.finki.emt.emtlab.service.application.impl;

import mk.ukim.finki.emt.emtlab.model.domain.Author;
import mk.ukim.finki.emt.emtlab.model.dto.CreateBookDto;
import mk.ukim.finki.emt.emtlab.model.dto.DisplayBookDto;
import mk.ukim.finki.emt.emtlab.model.exception.AuthorNotFoundException;
import mk.ukim.finki.emt.emtlab.model.exception.BookNotFoundException;
import mk.ukim.finki.emt.emtlab.model.projection.BookDetailedProjection;
import mk.ukim.finki.emt.emtlab.model.projection.BookProjection;
import mk.ukim.finki.emt.emtlab.service.application.BookApplicationService;
import mk.ukim.finki.emt.emtlab.service.domain.AuthorService;
import mk.ukim.finki.emt.emtlab.service.domain.BookService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BookApplicationServiceImpl implements BookApplicationService {

    private final BookService bookService;
    private final AuthorService authorService;

    public BookApplicationServiceImpl(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }

    @Override
    public Optional<DisplayBookDto> findById(Long id) {
        return bookService
                .findById(id)
                .map(DisplayBookDto::from);
    }

    @Override
    public List<DisplayBookDto> findAll() {
        return DisplayBookDto.from(bookService.findAll());
    }

    @Override
    public DisplayBookDto create(CreateBookDto createBookDto) {
        Author author=authorService
                .findById(createBookDto.authorId())
                .orElseThrow(()->new AuthorNotFoundException(createBookDto.authorId()));
        return DisplayBookDto.from(bookService.create(createBookDto.toBook(author)));
    }

    @Override
    public Optional<DisplayBookDto> update(Long id, CreateBookDto createBookDto) {
        Author author=authorService
                .findById(createBookDto.authorId())
                .orElseThrow(()-> new AuthorNotFoundException(createBookDto.authorId()));
        return bookService
                .update(id,createBookDto.toBook(author))
                .map(DisplayBookDto::from);
    }

    @Override
    public Optional<DisplayBookDto> deleteById(Long id) {
        return bookService
                .deleteById(id)
                .map(DisplayBookDto::from);
    }

    @Override
    public Optional<DisplayBookDto> rentBook(Long id) {
        return bookService
                .rentBook(id)
                .map(DisplayBookDto::from);
    }

    @Override
    public List<DisplayBookDto> filterBooks(Long a, Long b) {
       return DisplayBookDto.from(bookService.filterBooks(a,b));
    }

    @Override
    public Page<DisplayBookDto> findAll(int page, int size, String sortBy) {
        return bookService.findAll(page, size, sortBy)
                .map(DisplayBookDto::from);

    }

    @Override
    public List<BookProjection> findAllProjection() {
        return bookService.findAllProjection();
    }

    @Override
    public Optional<BookDetailedProjection> findBookDetailedById(Long id) {
        return bookService.findBookDetailedById(id);
    }

    @Override
    public List<DisplayBookDto> findWithAuthorAndCountry() {
        return bookService.findWithAuthorAndCountry().stream().map(DisplayBookDto::from).toList();
    }

    @Override
    public Optional<DisplayBookDto> findWithAuthorAndCountryById(Long id) {
        return bookService.findWithAuthorAndCountryById(id).map(DisplayBookDto::from);
    }


}
